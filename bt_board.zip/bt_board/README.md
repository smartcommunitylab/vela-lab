BLE Scanner
========================

This folder contains the code specifically developed for the BLE Scanner of the network. The application code is in 'ble_app_vela_lab/', while the sdk is in 'time_of_flight_ble/' (it is the same sdk used in the BLE ToF repository, therefore all the BLE ToF repo is included here).
